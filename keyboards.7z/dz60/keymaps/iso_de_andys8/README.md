# ISO DE layout

This layout is ISO-DE and similar to a standard 60 ISO layout. There are vim style arrow keys on the function layer. The bottom right is the expected default.
