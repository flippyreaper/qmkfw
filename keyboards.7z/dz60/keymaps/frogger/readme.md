![DZ60 Layout Image](https://i.redd.it/aa4usjtk5j701.jpg)

# Frogger's Keyboard Layout

This layouts is for someone with a dedicated arrow keys, but still wants arrows on home row as well.  I have one layer which is functionality, and another layer
which is really more around backlight stuff, because I rarely use it. Instead of a 2.25u shift as pictured, I have 2 1u keys.
