# LEdiodes Keymap for XD60 60% PCB

![LEdiodes Layer 0 Keymap for XD60](https://i.imgur.com/pDneawX.jpg)

## Additional Notes
Layer 0(default) Keymap for LEdiodes XD60.

## Build
To build the default keymap, simply run `make xd60:LEdiodes`.
