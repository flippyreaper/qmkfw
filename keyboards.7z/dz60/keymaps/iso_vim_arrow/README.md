# ISO layout with VIM style arrow cluster

This layout is ISO-DE and similar to a standard 60 ISO layout. There are vim style arrow keys on the function layer and in the bottom right corner of the main layer.

![Layout](https://i.imgur.com/Wu8VT43.png)

