# Edulpn Tsangan Keymap for the DZ60 PCB

## Additional Notes
Tsangan 60% Keymap for DZ60 + Fn layer.

### Layout
![Edulpn Tsangan Keymap for the DZ60](https://i.imgur.com/z7HHeH7.png)

## Build
To build the default keymap, simply run `make dz60:edulpn`.
