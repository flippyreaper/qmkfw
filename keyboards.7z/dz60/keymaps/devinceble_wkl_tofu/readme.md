# Devinceble AKA Vimwarrior WKL Tofu Keymap

Build Hex File:

    make dz60:devinceble_wkl_tofu

Flash Keyboard

    make dz60:devinceble_wkl_tofu:flash
