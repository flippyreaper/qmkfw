# DZ60 with splitted parts
### by Oliver Granlund

![Finished product](https://i.imgur.com/HlEo5Yg.jpg)

This is still under progress, but currently works on Windows as a daily driver.