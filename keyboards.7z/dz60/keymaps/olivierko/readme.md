# DZ60
### _BL:
Base layer with american ANSI layout.  

![_BL](https://i.imgur.com/BPMn7dk.png)
### _SL:
Swedish layer with ÅÄÖ at original positions.  

![_SL](https://i.imgur.com/I8QRh24.png)
### _FL:
Function layer including various extra keys.  

![_FL](https://i.imgur.com/nCbCIrZ.png)
### _CL:
Control layer for managing RGB and flashing.  

![_CL](https://i.imgur.com/QnoMgsb.png)
### Make command:
```sh
make dz60:olivierko:flash
```