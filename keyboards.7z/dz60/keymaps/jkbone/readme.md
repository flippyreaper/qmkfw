# JKBONE - ISO dz70

Split left shift, vim arrow keys & ISO setup. Keymap based on Macbooks with ISO uk/english international keyboard layouts.

[![JKBONE](https://i.imgur.com/FWP4IIi.png)](http://www.keyboard-layout-editor.com/#/gists/17b5b4c1248a66947575181ff98cb562)

[![Apple English International Layout](https://i.imgur.com/GxVqALg.png)](https://support.apple.com/en-us/HT201794)

