#pragma once
#define USB_MAX_POWER_CONSUMPTION 100
