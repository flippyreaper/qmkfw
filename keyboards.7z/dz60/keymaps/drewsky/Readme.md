# **DREWSKY'S DZ60 ANSI Layout**
![Imgur](https://i.imgur.com/v4zVbl7.jpg)


Layer 1 is default configuration, for the exception of the Space cadet shifts. Layer 2 is for WASD arrows and Media, which I have included both PREV and NEXT for Windows and macOS. Layer 3 is for RGB underglow. Legends in picture follow Layers. Modifier one is momentary, and the RGB layer is TT (TAP_TOGGLE)

Make example for this keyboard (after setting up your build environment):

    make dz60:drewsky

See the [build environment setup](https://docs.qmk.fm/#/getting_started_build_tools) and the [make instructions](https://docs.qmk.fm/#/getting_started_make_guide) for more information. Brand new to QMK? Start with our [Complete Newbs Guide](https://docs.qmk.fm/#/newbs).
