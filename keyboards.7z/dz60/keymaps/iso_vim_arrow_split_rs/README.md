# ISO layout with VIM style arrow cluster

Vim arrow keys with split right shift and backspace (currently not utilised in this layout but I thought I would add it to make it easier for people to add it for their layouts).
