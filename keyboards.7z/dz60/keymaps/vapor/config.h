
/*Keycodes I guess*/
//Cesky znaky
#define X_PLUS KC_1
#define X_ES KC_2
#define X_SS KC_3
#define X_CC KC_4
#define X_RR KC_5
#define X_ZZ KC_6
#define X_YY KC_7
#define X_AA KC_8
#define X_II KC_9
#define X_EE KC_0

//FN
#define X_LSFT MO(1)
#define X_NUMB MO(3)
#define X_CZ   MO(2)
#define X_FN   LT(9, KC_TAB)
#define X_SYS  MO(9)


//Default
#define X_MINS KC_SLSH
#define X_CARK KC_EQL
#define X_LBRC RALT(KC_F)
#define X_RBRC RALT(KC_G)
#define X_SCLN KC_GRV
#define X_APOS LSFT(KC_BSLS)
#define X_BSLS RALT(KC_Q)
#define X_SLSH LSFT(KC_LBRC)

//Shift US
#define X_TILD RALT(KC_1)
#define X_EXLM KC_DQUO
#define X_AT   RALT(KC_V)
#define X_HASH RALT(KC_X)
#define X_DLR  RALT(KC_SCLN)
#define X_PERC KC_UNDS
#define X_CIRC RALT(KC_6) //Upravit delay
#define X_AMPR RALT(KC_C)
#define X_ASTR RALT(KC_SLSH)
#define X_LPRN LSFT(KC_RBRC)
#define X_RPRN KC_RBRC
#define X_UNDS LSFT(KC_SLSH)
#define X_HACK LSFT(KC_EQL)

#define X_LCBR RALT(KC_B)
#define X_RCBR RALT(KC_N)
#define X_COLN LSFT(KC_DOT)
#define X_DQT  LSFT(KC_SCLN)
#define X_PIPE RALT(KC_W)
#define X_LABK RALT(KC_COMM)
#define X_RABK RALT(KC_DOT)
#define X_QUES LSFT(KC_COMM)


//number layer
#define X_EQLS KC_MINS
#define X_USHC KC_LBRC
#define X_USKR KC_SCLN

enum unicode_name {
  GRIN, // grinning face ๐
  TJOY, // tears of joy ๐
  SMILE, // grining face with smiling eyes ๐
  //Lowercase Vaporwave
  VaporlA,
  VaporlB,
  VaporlC,
  VaporlD, 
  VaporlE,
  VaporlF,
  VaporlG,
  VaporlH,
  VaporlI,
  VaporlJ,
  VaporlK,
  VaporlL,
  VaporlM,
  VaporlN,
  VaporlO,
  VaporlP,
  VaporlQ,
  VaporlR,
  VaporlS,
  VaporlT,
  VaporlU,
  VaporlV,
  VaporlW,
  VaporlX,
  VaporlY,
  VaporlZ,
    Vaporl0,
  Vaporl1,
  Vaporl2,
  Vaporl3,
  Vaporl4,
  Vaporl5,
  Vaporl6,
  Vaporl7,
  Vaporl8,
  Vaporl9,
  //Uppercase Vaporwave
  VaporuA,
  VaporuB,
  VaporuC,
  VaporuD,
  VaporuE,
  VaporuF,
  VaporuG,
  VaporuH,
  VaporuI,
  VaporuJ,
  VaporuK,
  VaporuL,
  VaporuM,
  VaporuN,
  VaporuO,
  VaporuP,
  VaporuQ,
  VaporuR,
  VaporuS,
  VaporuT,
  VaporuU,
  VaporuV,
  VaporuW,
  VaporuX,
  VaporuY,
  VaporuZ,
  Vaporu0,
  Vaporu1,
  Vaporu2,
  Vaporu3,
  Vaporu4,
  Vaporu5,
  Vaporu6,
  Vaporu7,
  Vaporu8,
  Vaporu9,
  //Kanji
  KanjiA,
  KanjiB,
  KanjiC,
  KanjiD, 
  KanjiE,
  KanjiF,
  KanjiG,
  KanjiH,
  KanjiI,
  KanjiJ,
  KanjiK,
  KanjiL,
  KanjiM,
  KanjiN,
  KanjiO,
  KanjiP,
  KanjiQ,
  KanjiR,
  KanjiS,
  KanjiT,
  KanjiU,
  KanjiV,
  KanjiW,
  KanjiX,
  KanjiY,
  KanjiZ,
  
  //Gothic Light
  GothLA,
  GothLB,
  GothLC,
  GothLD, 
  GothLE,
  GothLF,
  GothLG,
  GothLH,
  GothLI,
  GothLJ,
  GothLK,
  GothLL,
  GothLM,
  GothLN,
  GothLO,
  GothLP,
  GothLQ,
  GothLR,
  GothLS,
  GothLT,
  GothLU,
  GothLV,
  GothLW,
  GothLX,
  GothLY,
  GothLZ,
  
  
  //Gothic Bold
    GothBA,
  GothBB,
  GothBC,
  GothBD, 
  GothBE,
  GothBF,
  GothBG,
  GothBH,
  GothBI,
  GothBJ,
  GothBK,
  GothBL,
  GothBM,
  GothBN,
  GothBO,
  GothBP,
  GothBQ,
  GothBR,
  GothBS,
  GothBT,
  GothBU,
  GothBV,
  GothBW,
  GothBX,
  GothBY,
  GothBZ,
  
  

  
  //Handwrite Light
    HandLA,
  HandLB,
  HandLC,
  HandLD, 
  HandLE,
  HandLF,
  HandLG,
  HandLH,
  HandLI,
  HandLJ,
  HandLK,
  HandLL,
  HandLM,
  HandLN,
  HandLO,
  HandLP,
  HandLQ,
  HandLR,
  HandLS,
  HandLT,
  HandLU,
  HandLV,
  HandLW,
  HandLX,
  HandLY,
  HandLZ,
  
  //Twin double font   
  TwinUA,
  TwinUB,
  TwinUC,
  TwinUD, 
  TwinUE,
  TwinUF,
  TwinUG,
  TwinUH,
  TwinUI,
  TwinUJ,
  TwinUK,
  TwinUL,
  TwinUM,
  TwinUN,
  TwinUO,
  TwinUP,
  TwinUQ,
  TwinUR,
  TwinUS,
  TwinUT,
  TwinUU,
  TwinUV,
  TwinUW,
  TwinUX,
  TwinUY,
  TwinUZ,
    Twinu0,
  Twinu1,
  Twinu2,
  Twinu3,
  Twinu4,
  Twinu5,
  Twinu6,
  Twinu7,
  Twinu8,
  Twinu9,
  
  
  //Capital letters nevim jak vypadaj
  //0x1D00
  //*********** test
  
  //DownL
  
    DownLA,
  DownLB,
  DownLC,
  DownLD, 
  DownLE,
  DownLF,
  DownLG,
  DownLH,
  DownLI,
  DownLJ,
  DownLK,
  DownLL,
  DownLM,
  DownLN,
  DownLO,
  DownLP,
  DownLQ,
  DownLR,
  DownLS,
  DownLT,
  DownLU,
  DownLV,
  DownLW,
  DownLX,
  DownLY,
  DownLZ,
  
  //Boxed
  
    BoxedA,
  BoxedB,
  BoxedC,
  BoxedD, 
  BoxedE,
  BoxedF,
  BoxedG,
  BoxedH,
  BoxedI,
  BoxedJ,
  BoxedK,
  BoxedL,
  BoxedM,
  BoxedN,
  BoxedO,
  BoxedP,
  BoxedQ,
  BoxedR,
  BoxedS,
  BoxedT,
  BoxedU,
  BoxedV,
  BoxedW,
  BoxedX,
  BoxedY,
  BoxedZ,
  
  //RingL
   RingLA,
  RingLB,
  RingLC,
  RingLD, 
  RingLE,
  RingLF,
  RingLG,
  RingLH,
  RingLI,
  RingLJ,
  RingLK,
  RingLL,
  RingLM,
  RingLN,
  RingLO,
  RingLP,
  RingLQ,
  RingLR,
  RingLS,
  RingLT,
  RingLU,
  RingLV,
  RingLW,
  RingLX,
  RingLY,
  RingLZ,
  RingL0,
  RingL1,
  RingL2,
  RingL3,
  RingL4,
  RingL5,
  RingL6,
  RingL7,
  RingL8,
  RingL9,
  
  
  //RingUppercase
    RingUA,
  RingUB,
  RingUC,
  RingUD, 
  RingUE,
  RingUF,
  RingUG,
  RingUH,
  RingUI,
  RingUJ,
  RingUK,
  RingUL,
  RingUM,
  RingUN,
  RingUO,
  RingUP,
  RingUQ,
  RingUR,
  RingUS,
  RingUT,
  RingUU,
  RingUV,
  RingUW,
  RingUX,
  RingUY,
  RingUZ,
  RingU0,
  RingU1,
  RingU2,
  RingU3,
  RingU4,
  RingU5,
  RingU6,
  RingU7,
  RingU8,
  RingU9,
  

  
  
};


