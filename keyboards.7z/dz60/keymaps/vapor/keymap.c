#include QMK_KEYBOARD_H

///Prohodit = a + ?

// Přendat to do configu

// na vapor dat double mezeru

//cleannout layers



const uint16_t PROGMEM keymaps[][MATRIX_ROWS][MATRIX_COLS] = {


		
	//Default Layer
	//Layer 0
	LAYOUT( 
		RESET,  X_PLUS,  X_ES,    X_SS,    X_CC,     X_RR,   X_ZZ,   X_YY,   X_AA,   X_II,    X_EE,    X_MINS,  X_CARK, X_BSLS,  KC_X, 
		X_FN,    KC_Q,    KC_W,    KC_E,    KC_R,     KC_T,   KC_Y,   KC_U,   KC_I,   KC_O,    KC_P,    X_LBRC,  X_RBRC, KC_BSPC,
		X_NUMB,  KC_A,    KC_S,    KC_D,    KC_F,     KC_G,   KC_H,   KC_J,   KC_K,   KC_L,    X_SCLN,  X_APOS,   KC_ENT, 
		X_LSFT,  KC_NO, KC_Z,    KC_X,    KC_C,     KC_V,   KC_B,   KC_N,   KC_M,   KC_COMM, KC_DOT,  X_SLSH,  KC_RSFT, X_SYS,
		KC_LCTL, KC_LGUI, KC_LALT, KC_NO, KC_SPC, KC_NO,  KC_RALT, KC_X, KC_NO, KC_X, KC_RCTRL),
		
	//Shift + US layer
	//Shift
	//Layer 1
	LAYOUT( 
		X_TILD, X_EXLM, X_AT , X_HASH, X_DLR, X_PERC, X_CIRC, X_AMPR, X_ASTR, X_LPRN, X_RPRN, X_UNDS, X_HACK, X_PIPE, KC_X,
		_______, LSFT(KC_Q), LSFT(KC_W), LSFT(KC_E), LSFT(KC_R), LSFT(KC_T), LSFT(KC_Y), LSFT(KC_U), LSFT(KC_I), LSFT(KC_O), LSFT(KC_P), X_LCBR, X_RCBR, KC_BSPC,
		_______, LSFT(KC_A), LSFT(KC_S), LSFT(KC_D), LSFT(KC_F), LSFT(KC_G), LSFT(KC_H), LSFT(KC_J), LSFT(KC_K), LSFT(KC_L), X_COLN, X_DQT,  KC_ENT, 
		_______, KC_NO, LSFT(KC_Z), LSFT(KC_X), LSFT(KC_C), LSFT(KC_V), LSFT(KC_B), LSFT(KC_N), LSFT(KC_M), X_LABK, X_RABK, X_QUES, KC_RSFT, _______,
		_______, _______, _______,KC_NO, _______,KC_NO, _______, _______,KC_NO, _______, _______),  

		
		
	//Czech Layer
	//Layer 2
	LAYOUT(
		KC_ESC, KC_1, KC_2, KC_3, KC_4, KC_5, KC_6, KC_7, KC_8, KC_9, KC_0, KC_MINS, KC_EQL, KC_BSLS,  KC_X,
		KC_TAB, KC_Q, KC_W, KC_E, KC_R, KC_T, KC_Y, KC_U, KC_I, KC_O, KC_P, KC_LBRC, KC_RBRC,KC_BSPC, 
		X_NUMB, KC_A, KC_S, KC_D, KC_F, KC_G, KC_H, KC_J, KC_K, KC_L, KC_SCLN, KC_QUOT, KC_ENT, 
		KC_LSFT, KC_NO, KC_Z, KC_X, KC_C, KC_V, KC_B, KC_N,KC_M, KC_COMM, KC_DOT, KC_SLSH, KC_UP, X_SYS,  
		_______, _______, _______,KC_NO, _______,KC_NO, _______, KC_LEFT,KC_NO, KC_DOWN, KC_RIGHT), 	
		
		

	//Second Layer / Number layer
	//Caps
	//Layer 3
	LAYOUT(
		KC_GRV, LSFT(KC_1), LSFT(KC_2), LSFT(KC_3), LSFT(KC_4), LSFT(KC_5), LSFT(KC_6), LSFT(KC_7), LSFT(KC_8), LSFT(KC_9), LSFT(KC_0), X_EQLS, X_PLUS, X_PIPE, KC_DEL,
		_______, KC_MPRV, KC_MPLY, KC_MNXT, _______, _______, _______,KC_PGUP, KC_UP, KC_PGDN, KC_PSCR, X_USHC, _______,  KC_DEL,
		_______, _______, KC_VOLD, KC_VOLU, KC_MUTE, _______, KC_HOME,KC_LEFT, KC_DOWN, KC_RGHT, X_USKR, _______,  _______, KC_X, 
		_______, KC_NO, _______, _______, _______, _______,KC_END, _______, _______, _______, _______, _______, _______, 
		_______, _______, _______,KC_NO, _______,KC_NO, _______, _______,KC_NO, _______, _______),  

 
		
	//Cooking layer
	//Layer 4
	LAYOUT(
		KC_ESC, LSFT(KC_1), LSFT(KC_2), LSFT(KC_3), LSFT(KC_4), LSFT(KC_5), LSFT(KC_6), LSFT(KC_7), LSFT(KC_8), LSFT(KC_9), LSFT(KC_0), X_EQLS, X_PLUS, X_PIPE, KC_DEL,
		KC_TAB, KC_Q, KC_W, KC_E, KC_R, KC_T, KC_Y, KC_U, KC_I, KC_O, KC_P, KC_LBRC, KC_RBRC,KC_BSPC, 
		MO(5), KC_A, KC_S, KC_D, KC_F, KC_G, KC_H, KC_J, KC_K, KC_L, KC_SCLN, KC_QUOT, KC_ENT, 
		KC_LSFT, KC_NO, KC_Z, KC_X, KC_C, KC_V, KC_B, KC_N,KC_M, KC_COMM, KC_DOT, KC_SLSH, KC_UP, X_SYS,  
		_______, _______, _______,KC_NO, _______,KC_NO, _______, KC_LEFT,KC_NO, KC_DOWN, KC_RIGHT),  
		
		
		
		//TEEST
	//Caps
	//Layer 5
	LAYOUT(
		KC_GRV, LSFT(KC_1), LSFT(KC_2), LSFT(KC_3), LSFT(KC_4), LSFT(KC_5), LSFT(KC_6), LSFT(KC_7), LSFT(KC_8), LSFT(KC_9), LSFT(KC_0), X_EQLS, X_PLUS, X_PIPE, KC_DEL,
		_______, KC_MPRV, KC_MPLY, KC_MNXT, _______, _______, _______,KC_PGUP, KC_UP, KC_PGDN, KC_PSCR, X_USHC, _______,  KC_DEL,
		_______, _______, KC_VOLD, KC_VOLU, KC_MUTE, _______, KC_HOME,KC_LEFT, KC_DOWN, KC_RGHT, X_USKR, _______,  _______, KC_X, 
		_______, KC_NO, _______, _______, _______, _______,KC_END, _______, _______, _______, _______, _______, _______, 
		_______, _______, _______,KC_NO, _______,KC_NO, _______, _______,KC_NO, _______, _______),  
		
		
	//Vaporwave lowercase
	//Layer 6
	LAYOUT(
		_______, X(Vaporl1), X(Vaporl2), X(Vaporl3), X(Vaporl4), X(Vaporl5), X(Vaporl6), X(Vaporl7), X(Vaporl8), X(Vaporl9), X(Vaporl0), _______, _______, _______, _______,
		_______, X(VaporlQ), X(VaporlW), X(VaporlE), X(VaporlR), X(VaporlT), X(VaporlZ), X(VaporlU), X(VaporlI), X(VaporlO), X(VaporlP), _______, _______, _______, 
		_______, X(VaporlA), X(VaporlS), X(VaporlD), X(VaporlF), X(VaporlG), X(VaporlH), X(VaporlJ), X(VaporlK), X(VaporlL), _______, _______, _______,  
		MO(7), KC_NO,   X(VaporlY), X(VaporlX), X(VaporlC), X(VaporlV), X(VaporlB), X(VaporlN), X(VaporlM), _______, _______, _______, _______, _______, 
		_______, _______, _______, KC_NO,   _______, KC_NO,   _______, _______, KC_NO,   _______, _______),  
		
		
		
	//Vaporwave uppercase
	//Layer 7
	LAYOUT(
		_______, X(Vaporu1), X(Vaporu2), X(Vaporu3), X(Vaporu4), X(Vaporu5), X(Vaporu6), X(Vaporu7), X(Vaporu8), X(Vaporu9), X(Vaporu0), _______, _______, _______, _______,
		_______, X(VaporuQ), X(VaporuW), X(VaporuE), X(VaporuR), X(VaporuT), X(VaporuZ), X(VaporuU), X(VaporuI), X(VaporuO), X(VaporuP), _______, _______, _______, 
		_______, X(VaporuA), X(VaporuS), X(VaporuD), X(VaporuF), X(VaporuG), X(VaporuH), X(VaporuJ), X(VaporuK), X(VaporuL), _______, _______, _______,  
		_______, KC_NO,   X(VaporuY), X(VaporuX), X(VaporuC), X(VaporuV), X(VaporuB), X(VaporuN), X(VaporuM), _______, _______, _______, _______, _______, 
		_______, _______, _______, KC_NO,   _______, KC_NO,   _______, _______, KC_NO,   _______, _______),
	
	
	
	
	//Kanji
	//layer 8
	

		LAYOUT(
		_______, _______, _______, _______, _______, _______, _______, _______, _______, _______, _______, _______, _______, _______, _______,
		_______, X(KanjiQ), X(KanjiW), X(KanjiE), X(KanjiR), X(KanjiT), X(KanjiZ), X(KanjiU), X(KanjiI), X(KanjiO), X(KanjiP), _______, _______, _______, 
		_______, X(KanjiA), X(KanjiS), X(KanjiD), X(KanjiF), X(KanjiG), X(KanjiH), X(KanjiJ), X(KanjiK), X(KanjiL), _______, _______, _______,  
		_______, KC_NO,   X(KanjiY), X(KanjiX), X(KanjiC), X(KanjiV), X(KanjiB), X(KanjiN), X(KanjiM), _______, _______, _______, _______, _______, 
		_______, _______, _______, KC_NO,   _______, KC_NO,   _______, _______, KC_NO,   _______, _______),
	
	
	
	//Gothlic lajt
	//layer9
	
		LAYOUT(
		_______, _______, _______, _______, _______, _______, _______, _______, _______, _______, _______, _______, _______, _______, _______,
		_______, X(GothLQ), X(GothLW), X(GothLE), X(GothLR), X(GothLT), X(GothLZ), X(GothLU), X(GothLI), X(GothLO), X(GothLP), _______, _______, _______, 
		_______, X(GothLA), X(GothLS), X(GothLD), X(GothLF), X(GothLG), X(GothLH), X(GothLJ), X(GothLK), X(GothLL), _______, _______, _______,  
		_______, KC_NO,   X(GothLY), X(GothLX), X(GothLC), X(GothLV), X(GothLB), X(GothLN), X(GothLM), _______, _______, _______, _______, _______, 
		_______, _______, _______, KC_NO,   _______, KC_NO,   _______, _______, KC_NO,   _______, _______),
	
	
	
	//Gothic bold
	//layer10

		LAYOUT(
		_______, _______, _______, _______, _______, _______, _______, _______, _______, _______, _______, _______, _______, _______, _______,
		_______, X(GothBQ), X(GothBW), X(GothBE), X(GothBR), X(GothBT), X(GothBZ), X(GothBU), X(GothBI), X(GothBO), X(GothBP), _______, _______, _______, 
		_______, X(GothBA), X(GothBS), X(GothBD), X(GothBF), X(GothBG), X(GothBH), X(GothBJ), X(GothBK), X(GothBL), _______, _______, _______,  
		_______, KC_NO,   X(GothBY), X(GothBX), X(GothBC), X(GothBV), X(GothBB), X(GothBN), X(GothBM), _______, _______, _______, _______, _______, 
		_______, _______, _______, KC_NO,   _______, KC_NO,   _______, _______, KC_NO,   _______, _______),
	
	
	
	
	

	
	

	
//Handwrite light
//layer11
		LAYOUT(
		_______, _______, _______, _______, _______, _______, _______, _______, _______, _______, _______, _______, _______, _______, _______,
		_______, X(HandLQ), X(HandLW), X(HandLE), X(HandLR), X(HandLT), X(HandLZ), X(HandLU), X(HandLI), X(HandLO), X(HandLP), _______, _______, _______, 
		_______, X(HandLA), X(HandLS), X(HandLD), X(HandLF), X(HandLG), X(HandLH), X(HandLJ), X(HandLK), X(HandLL), _______, _______, _______,  
		_______, KC_NO,   X(HandLY), X(HandLX), X(HandLC), X(HandLV), X(HandLB), X(HandLN), X(HandLM), _______, _______, _______, _______, _______, 
		_______, _______, _______, KC_NO,   _______, KC_NO,   _______, _______, KC_NO,   _______, _______),
	
	
	
	//Twin font
	//layer 12
		LAYOUT(
		_______, X(Twinu1), X(Twinu2), X(Twinu3), X(Twinu4), X(Twinu5), X(Twinu6), X(Twinu7), X(Twinu8), X(Twinu9), X(Twinu0), _______, _______, _______, _______,
		_______, X(TwinUQ), X(TwinUW), X(TwinUE), X(TwinUR), X(TwinUT), X(TwinUZ), X(TwinUU), X(TwinUI), X(TwinUO), X(TwinUP), _______, _______, _______, 
		_______, X(TwinUA), X(TwinUS), X(TwinUD), X(TwinUF), X(TwinUG), X(TwinUH), X(TwinUJ), X(TwinUK), X(TwinUL), _______, _______, _______,  
		_______, KC_NO,   X(TwinUY), X(TwinUX), X(TwinUC), X(TwinUV), X(TwinUB), X(TwinUN), X(TwinUM), _______, _______, _______, _______, _______, 
		_______, _______, _______, KC_NO,   _______, KC_NO,   _______, _______, KC_NO,   _______, _______),
	
	
	
	
	//Upside down bitch lower
//layer 13
		LAYOUT(
		_______, _______, _______, _______, _______, _______, _______, _______, _______, _______, _______, _______, _______, _______, _______,
		_______, X(DownLQ), X(DownLW), X(DownLE), X(DownLR), X(DownLT), X(DownLZ), X(DownLU), X(DownLI), X(DownLO), X(DownLP), _______, _______, _______, 
		_______, X(DownLA), X(DownLS), X(DownLD), X(DownLF), X(DownLG), X(DownLH), X(DownLJ), X(DownLK), X(DownLL), _______, _______, _______,  
		_______, KC_NO,   X(DownLY), X(DownLX), X(DownLC), X(DownLV), X(DownLB), X(DownLN), X(DownLM), _______, _______, _______, _______, _______, 
		_______, _______, _______, KC_NO,   _______, KC_NO,   _______, _______, KC_NO,   _______, _______),
	
	
	
	
	
//boxed
	//layer 14

	LAYOUT(
		_______, _______, _______, _______, _______, _______, _______, _______, _______, _______, _______, _______, _______, _______, _______,
		_______, X(BoxedQ), X(BoxedW), X(BoxedE), X(BoxedR), X(BoxedT), X(BoxedZ), X(BoxedU), X(BoxedI), X(BoxedO), X(BoxedP), _______, _______, _______, 
		_______, X(BoxedA), X(BoxedS), X(BoxedD), X(BoxedF), X(BoxedG), X(BoxedH), X(BoxedJ), X(BoxedK), X(BoxedL), _______, _______, _______,  
		_______, KC_NO,   X(BoxedY), X(BoxedX), X(BoxedC), X(BoxedV), X(BoxedB), X(BoxedN), X(BoxedM), _______, _______, _______, _______, _______, 
		_______, _______, _______, KC_NO,   _______, KC_NO,   _______, _______, KC_NO,   _______, _______),
	
	
	
	
	//Circle of ded
//layer 15
		LAYOUT(
		_______, X(RingL1), X(RingL2), X(RingL3), X(RingL4), X(RingL5), X(RingL6), X(RingL7), X(RingL8), X(RingL9), X(RingL0), _______, _______, _______, _______,
		_______, X(RingLQ), X(RingLW), X(RingLE), X(RingLR), X(RingLT), X(RingLZ), X(RingLU), X(RingLI), X(RingLO), X(RingLP), _______, _______, _______, 
		_______, X(RingLA), X(RingLS), X(RingLD), X(RingLF), X(RingLG), X(RingLH), X(RingLJ), X(RingLK), X(RingLL), _______, _______, _______,  
		_______, KC_NO,   X(RingLY), X(RingLX), X(RingLC), X(RingLV), X(RingLB), X(RingLN), X(RingLM), _______, _______, _______, _______, _______, 
		_______, _______, _______, KC_NO,   _______, KC_NO,   _______, _______, KC_NO,   _______, _______),
	
	
	
	
	

	//Circle uper
	//layer 16
		LAYOUT(
		_______, X(RingU1), X(RingU2), X(RingU3), X(RingU4), X(RingU5), X(RingU6), X(RingU7), X(RingU8), X(RingU9), X(RingU0), _______, _______, _______, _______,
		_______, X(RingUQ), X(RingUW), X(RingUE), X(RingUR), X(RingUT), X(RingUZ), X(RingUU), X(RingUI), X(RingUO), X(RingUP), _______, _______, _______, 
		_______, X(RingUA), X(RingUS), X(RingUD), X(RingUF), X(RingUG), X(RingUH), X(RingUJ), X(RingUK), X(RingUL), _______, _______, _______,  
		_______, KC_NO,   X(RingUY), X(RingUX), X(RingUC), X(RingUV), X(RingUB), X(RingUN), X(RingUM), _______, _______, _______, _______, _______, 
		_______, _______, _______, KC_NO,   _______, KC_NO,   _______, _______, KC_NO,   _______, _______),
	
	
	
	
	

	


	
	
	
	
	

	


	

	

	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	//Unused layer
	//Layer 17
	LAYOUT(
		_______, _______, _______, _______, _______, _______, _______, _______, _______, _______, _______, _______, _______, _______, _______,
		_______, _______, _______, _______, _______, _______, _______, _______, _______, _______, _______, _______, _______, _______, 
		_______, _______, _______, _______, _______, _______, _______, _______, _______, _______, _______, _______, _______,  
		_______, KC_NO,   _______, _______, _______, _______, _______, _______, _______, _______, _______, _______, _______, _______, 
		_______, _______, _______, KC_NO,   _______, KC_NO,   _______, _______, KC_NO,   _______, _______),  
		
	
		
		
	//F-Row layer
	//Layer 18
	LAYOUT(
		KC_ESC,  KC_F1,   KC_F2,   KC_F3,   KC_F4,   KC_F5,   KC_F6,   KC_F7,   KC_F8,   KC_F9,   KC_F10,   KC_F11, KC_F12,  KC_DEL, _______,
		 TO(0), TO(1), TO(2), TO(3), TO(4), TO(5), TO(6), TO(7), TO(8), TO(9), TO(10), X(SMILE), X(TJOY), X(GRIN), 
KC_CAPS, RGB_TOG, RGB_MOD, RGB_HUI, RGB_HUD, RGB_SAI, RGB_SAD, RGB_VAI, RGB_VAD,  _______, _______, _______, _______,  
		_______, KC_NO,   BL_DEC, BL_TOGG, BL_INC, BL_STEP, _______, _______, _______, _______, _______, _______, _______, _______, 
		TO(17), _______, _______, KC_NO,   RESET, KC_NO,   _______, _______, KC_NO,   _______, _______),  
		
	
	 
	
};

  const uint32_t PROGMEM unicode_map[] = {
  [GRIN] = 0x1F600,
  [TJOY] = 0x1F602,
  [SMILE] = 0x1F601,
//Vaporwave Lowercase
  [VaporlA] = 0xFF41,
  [VaporlB] = 0xFF42,
  [VaporlC] = 0xFF43,
  [VaporlD] = 0xFF44,
  [VaporlE] = 0xFF45,
  [VaporlF] = 0xFF46,
  [VaporlG] = 0xFF47,
  [VaporlH] = 0xFF48,
  [VaporlI] = 0xFF49,
  [VaporlJ] = 0xFF4A,
  [VaporlK] = 0xFF4B,
  [VaporlL] = 0xFF4C,
  [VaporlM] = 0xFF4D,
  [VaporlN] = 0xFF4E,
  [VaporlO] = 0xFF4F,
  [VaporlP] = 0xFF50,
  [VaporlQ] = 0xFF51,
  [VaporlR] = 0xFF52,
  [VaporlS] = 0xFF53,
  [VaporlT] = 0xFF54,
  [VaporlU] = 0xFF55,
  [VaporlV] = 0xFF56,
  [VaporlW] = 0xFF57,
  [VaporlX] = 0xFF58,
  [VaporlY] = 0xFF59,
  [VaporlZ] = 0xFF5A,
  [Vaporl0] = 0xFF09,
  [Vaporl1] = 0xFF01,
  [Vaporl2] = 0xFF20,
  [Vaporl3] = 0xFF03,
  [Vaporl4] = 0xFF04,
  [Vaporl5] = 0xFF05,
  [Vaporl6] = 0xFF3E,
  [Vaporl7] = 0xFF06,
  [Vaporl8] = 0xFF0A,
  [Vaporl9] = 0xFF08,
  
//Vaporware uppercase
  [VaporuA] = 0xFF21,
  [VaporuB] = 0xFF22,
  [VaporuC] = 0xFF23,
  [VaporuD] = 0xFF24,
  [VaporuE] = 0xFF25,
  [VaporuF] = 0xFF26,
  [VaporuG] = 0xFF27,
  [VaporuH] = 0xFF28,
  [VaporuI] = 0xFF29,
  [VaporuJ] = 0xFF2A,
  [VaporuK] = 0xFF2B,
  [VaporuL] = 0xFF2C,
  [VaporuM] = 0xFF2D,
  [VaporuN] = 0xFF2E,
  [VaporuO] = 0xFF2F,
  [VaporuP] = 0xFF30,
  [VaporuQ] = 0xFF31,
  [VaporuR] = 0xFF32,
  [VaporuS] = 0xFF33,
  [VaporuT] = 0xFF34,
  [VaporuU] = 0xFF35,
  [VaporuV] = 0xFF36,
  [VaporuW] = 0xFF37,
  [VaporuX] = 0xFF38,
  [VaporuY] = 0xFF39,
  [VaporuZ] = 0xFF3A,
  [Vaporu0] = 0xFF10,
  [Vaporu1] = 0xFF11,
  [Vaporu2] = 0xFF12,
  [Vaporu3] = 0xFF13,
  [Vaporu4] = 0xFF14,
  [Vaporu5] = 0xFF15,
  [Vaporu6] = 0xFF16,
  [Vaporu7] = 0xFF17,
  [Vaporu8] = 0xFF18,
  [Vaporu9] = 0xFF19,
  
  //Kanji
  [KanjiA] = 0x5342,
  [KanjiB] = 0x4E43,
  [KanjiC] = 0x531A,
  [KanjiD] = 0x5200,
  [KanjiE] = 0x4E47,
  [KanjiF] = 0x5343,
  [KanjiG] = 0x53B6,
  [KanjiH] = 0x5344,
  [KanjiI] = 0x5DE5,
  [KanjiJ] = 0x4E01,
  [KanjiK] = 0x957F,
  [KanjiL] = 0x4E5A,
  [KanjiM] = 0x4ECE,
  [KanjiN] = 0xD841, //0xDE28
  [KanjiO] = 0x53E3,
  [KanjiP] = 0x5C38,
  [KanjiQ] = 0x353F,
  [KanjiR] = 0x5C3A,
  [KanjiS] = 0x4E02,
  [KanjiT] = 0x4E05,
  [KanjiU] = 0x51F5,
  [KanjiV] = 0x30EA,
  [KanjiW] = 0x5C71,
  [KanjiX] = 0x4E42,
  [KanjiY] = 0x4E2B,
  [KanjiZ] = 0x4E59,
  
  
  
  //Gothlic Light
  [GothLA] = 0xDD1E,
  [GothLB] = 0xDD1F,
  [GothLC] = 0xDD20,
  [GothLD] = 0xDD21,
  [GothLE] = 0xDD22,
  [GothLF] = 0xDD23,
  [GothLG] = 0xDD24,
  [GothLH] = 0xDD25,
  [GothLI] = 0xDD26,
  [GothLJ] = 0xDD27,
  [GothLK] = 0xDD28,
  [GothLL] = 0xDD29,
  [GothLM] = 0xDD2A,
  [GothLN] = 0xDD2B,
  [GothLO] = 0xDD2C,
  [GothLP] = 0xDD2D,
  [GothLQ] = 0xDD2E,
  [GothLR] = 0xDD2F,
  [GothLS] = 0xDD30,
  [GothLT] = 0xDD31,
  [GothLU] = 0xDD32,
  [GothLV] = 0xDD33,
  [GothLW] = 0xDD34,
  [GothLX] = 0xDD35,
  [GothLY] = 0xDD36,
  [GothLZ] = 0xDD37,
  
  
  
  //Gothic Bold
  [GothBA] = 0xDD86,
  [GothBB] = 0xDD87,
  [GothBC] = 0xDD88,
  [GothBD] = 0xDD89,
  [GothBE] = 0xDD8A,
  [GothBF] = 0xDD8B,
  [GothBG] = 0xDD8C,
  [GothBH] = 0xDD8D,
  [GothBI] = 0xDD8E,
  [GothBJ] = 0xDD8F,
  [GothBK] = 0xDD90,
  [GothBL] = 0xDD91,
  [GothBM] = 0xDD92,
  [GothBN] = 0xDD93,
  [GothBO] = 0xDD94,
  [GothBP] = 0xDD95,
  [GothBQ] = 0xDD96,
  [GothBR] = 0xDD97,
  [GothBS] = 0xDD98,
  [GothBT] = 0xDD99,
  [GothBU] = 0xDD9A,
  [GothBV] = 0xDD9B,
  [GothBW] = 0xDD9C,
  [GothBX] = 0xDD9D,
  [GothBY] = 0xDD9E,
  [GothBZ] = 0xDD9F,
  
  

  
  //Handwirte Light
  [HandLA] = 0xDCB6,
  [HandLB] = 0xDCB7,
  [HandLC] = 0xDCB8,
  [HandLD] = 0xDCB9,
  [HandLE] = 0xDCBA,
  [HandLF] = 0xDCBB,
  [HandLG] = 0xDCBC,
  [HandLH] = 0xDCBD,
  [HandLI] = 0xDCBE,
  [HandLJ] = 0xDCBF,
  [HandLK] = 0xDCC0,
  [HandLL] = 0xDCC1,
  [HandLM] = 0xDCC2,
  [HandLN] = 0xDCC3,
  [HandLO] = 0xDCC4,
  [HandLP] = 0xDCC5,
  [HandLQ] = 0xDCC6,
  [HandLR] = 0xDCC7,
  [HandLS] = 0xDCC8,
  [HandLT] = 0xDCC9,
  [HandLU] = 0xDCCA,
  [HandLV] = 0xDCCB,
  [HandLW] = 0xDCCC,
  [HandLX] = 0xDCCD,
  [HandLY] = 0xDCCE,
  [HandLZ] = 0xDCCF,
  
  
  //Twin double font
  [TwinUA] = 0xDD52,
  [TwinUB] = 0xDD53,
  [TwinUC] = 0xDD54,
  [TwinUD] = 0xDD55,
  [TwinUE] = 0xDD56,
  [TwinUF] = 0xDD57,
  [TwinUG] = 0xDD58,
  [TwinUH] = 0xDD59,
  [TwinUI] = 0xDD5A,
  [TwinUJ] = 0xDD5B,
  [TwinUK] = 0xDD5C,
  [TwinUL] = 0xDD5D,
  [TwinUM] = 0xDD5E,
  [TwinUN] = 0xDD5F,
  [TwinUO] = 0xDD60,
  [TwinUP] = 0xDD61,
  [TwinUQ] = 0xDD62,
  [TwinUR] = 0xDD63,
  [TwinUS] = 0xDD64,
  [TwinUT] = 0xDD65,
  [TwinUU] = 0xDD66,
  [TwinUV] = 0xDD67,
  [TwinUW] = 0xDD68,
  [TwinUX] = 0xDD69,
  [TwinUY] = 0xDD6A,
  [TwinUZ] = 0xDD6B,
  [Twinu0] = 0xDFD8,
  [Twinu1] = 0xDFD9,
  [Twinu2] = 0xDFDA,
  [Twinu3] = 0xDFDB,
  [Twinu4] = 0xDFDC,
  [Twinu5] = 0xDFDD,
  [Twinu6] = 0xDFDE,
  [Twinu7] = 0xDFDF,
  [Twinu8] = 0xDFE0,
  [Twinu9] = 0xDFE1,
  //DownL
  [DownLA] = 0x0250,
  [DownLB] = 0x0071,
  [DownLC] = 0x0254,
  [DownLD] = 0x0070,
  [DownLE] = 0x01DD,
  [DownLF] = 0x025F,
  [DownLG] = 0x0253,
  [DownLH] = 0x0265,
  [DownLI] = 0x0131,
  [DownLJ] = 0x027E,
  [DownLK] = 0x029E,
  [DownLL] = 0x006C,
  [DownLM] = 0x026F,
  [DownLN] = 0x0075,
  [DownLO] = 0x006F,
  [DownLP] = 0x0064,
  [DownLQ] = 0x0062,
  [DownLR] = 0x0279,
  [DownLS] = 0x0073,
  [DownLT] = 0x0287,
  [DownLU] = 0x006E,
  [DownLV] = 0x028C,
  [DownLW] = 0x028D,
  [DownLX] = 0x0078,
  [DownLY] = 0x028E,
  [DownLZ] = 0x007A,
  
  
  //Boxed
  [BoxedA] = 0xDD70,
  [BoxedB] = 0xDD71,
  [BoxedC] = 0xDD72,
  [BoxedD] = 0xDD73,
  [BoxedE] = 0xDD74,
  [BoxedF] = 0xDD75,
  [BoxedG] = 0xDD76,
  [BoxedH] = 0xDD77,
  [BoxedI] = 0xDD78,
  [BoxedJ] = 0xDD79,
  [BoxedK] = 0xDD7A,
  [BoxedL] = 0xDD7B,
  [BoxedM] = 0xDD7C,
  [BoxedN] = 0xDD7D,
  [BoxedO] = 0xDD7E,
  [BoxedP] = 0xDD7F,
  [BoxedQ] = 0xDD80,
  [BoxedR] = 0xDD81,
  [BoxedS] = 0xDD82,
  [BoxedT] = 0xDD83,
  [BoxedU] = 0xDD84,
  [BoxedV] = 0xDD85,
  [BoxedW] = 0xDD86,
  [BoxedX] = 0xDD87,
  [BoxedY] = 0xDD88,
  [BoxedZ] = 0xDD89,
  //0xDD98 SOS, dodat
  
  //RingL
  [RingLA] = 0x24D0,
  [RingLB] = 0x24D1,
  [RingLC] = 0x24D2,
  [RingLD] = 0x24D3,
  [RingLE] = 0x24D4,
  [RingLF] = 0x24D5,
  [RingLG] = 0x24D6,
  [RingLH] = 0x24D7,
  [RingLI] = 0x24D8,
  [RingLJ] = 0x24D9,
  [RingLK] = 0x24DA,
  [RingLL] = 0x24DB,
  [RingLM] = 0x24DC,
  [RingLN] = 0x24DD,
  [RingLO] = 0x24DE,
  [RingLP] = 0x24DF,
  [RingLQ] = 0x24E0,
  [RingLR] = 0x24E1,
  [RingLS] = 0x24E2,
  [RingLT] = 0x24E3,
  [RingLU] = 0x24E4,
  [RingLV] = 0x24E5,
  [RingLW] = 0x24E6,
  [RingLX] = 0x24E7,
  [RingLY] = 0x24E8,
  [RingLZ] = 0x24E9,
  [RingL1] = 0x2460,
  [RingL2] = 0x2461,
  [RingL3] = 0x2462,
  [RingL4] = 0x2463,
  [RingL5] = 0x2464,
  [RingL6] = 0x2465,
  [RingL7] = 0x2466,
  [RingL8] = 0x2467,
  [RingL9] = 0x2468,
  [RingL0] = 0x24EA,
  
  
  //RingU
  [RingUA] = 0x24B6,
  [RingUB] = 0x24B7,
  [RingUC] = 0x24B8,
  [RingUD] = 0x24B9,
  [RingUE] = 0x24BA,
  [RingUF] = 0x24BB,
  [RingUG] = 0x24BC,
  [RingUH] = 0x24BD,
  [RingUI] = 0x24BE,
  [RingUJ] = 0x24BF,
  [RingUK] = 0x24C0,
  [RingUL] = 0x24C1,
  [RingUM] = 0x24C2,
  [RingUN] = 0x24C3,
  [RingUO] = 0x24C4,
  [RingUP] = 0x24C5,
  [RingUQ] = 0x24C6,
  [RingUR] = 0x24C7,
  [RingUS] = 0x24C8,
  [RingUT] = 0x24C9,
  [RingUU] = 0x24CA,
  [RingUV] = 0x24CB,
  [RingUW] = 0x24CC,
  [RingUX] = 0x24CD,
  [RingUY] = 0x24CE,
  [RingUZ] = 0x24CF,
  [RingU0] = 0x24FF,
  [RingU1] = 0x24F5,
  [RingU2] = 0x24F6,
  [RingU3] = 0x24F7,
  [RingU4] = 0x24F8,
  [RingU5] = 0x24F9,
  [RingU6] = 0x24FA,
  [RingU7] = 0x24FB,
  [RingU8] = 0x24FC,
  [RingU9] = 0x24FD,
  
  
  
};
