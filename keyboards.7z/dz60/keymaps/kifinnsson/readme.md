# kifinnsson's Colemak angle mod ansi-ish layout
-----------------

Keymap for my non-standard DZ60 layout. It is an ansi layout on the right and iso on the left (ie 1.25x left shift). This is to implement the angle mod on for Colemak which is the base layer. A side effect of this is that I have an extra key on row 4, which sits between the "b" and "k" keys in Colemak. I use this key as a switch to layer 2 which is my macro layer.

