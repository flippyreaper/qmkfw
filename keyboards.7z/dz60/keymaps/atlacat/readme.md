// Template made by Atlacat for DZ 60% keyboard

The design of the keyboard is coppied from other makers but change to be more dynamic.
The main difference is the switching between layers to keep things simple for me
