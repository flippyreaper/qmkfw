![60_ansi DZ60 base layer](https://i.imgur.com/MqBLh3D.png)

![60_ansi DZ60 fn layer](https://i.imgur.com/ml1djHi.png)

# 60_ansi DZ60 Layout

This is a basic keymap for the 60_ansi layout of the DZ60.
The default layer is normal ANSI and the Fn layer is used for RGB
and backlighting functions.
