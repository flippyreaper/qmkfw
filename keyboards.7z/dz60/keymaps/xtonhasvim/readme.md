# Xton has a DZ60 and it's Vimtastic!

Mine has a split spacebar, no arrowkeys and an opaque case. Changes from the default layout:

* Vim mode toggled by hitting left spacebar (see `users/xtonhasvim`). Reusing the capslock LED to indicate VIM is on.
* Momentary directional control by holding down `;`.
* Mousekeys toggled with middle space button.
* Escape is dual-function with control (which replaces capslock AS IT SHOULD BE).
* Bottom left key is the "halp my kb doesn't work" key that always dumps you back to QWERTY.

