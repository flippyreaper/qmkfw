# ISO DE layout

This layout is ISO-DE and similar to a standard 60 ISO layout. The bottom right has 5x 1u keys.
Right shift is split to add a function key.
