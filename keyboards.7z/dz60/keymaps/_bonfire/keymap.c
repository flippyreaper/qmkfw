#include QMK_KEYBOARD_H

/**
 * Bonfire Layout
 * v6.1.0
 *
 * @author Ethan Beyer
 *
 */
#include "keymap-parts/defs.c"
#include "keymap-parts/layers.c"
#include "keymap-parts/functions.c"
