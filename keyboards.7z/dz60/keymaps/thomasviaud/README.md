## French ISO Layout

Here is a very simple version of a French ISO Layout (handled by OS).
Feel free to take this as base for your own layout.
